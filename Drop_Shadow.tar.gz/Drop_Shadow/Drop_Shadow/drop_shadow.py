from PIL import Image, ImageFilter
import os

'''
Inputs: foreground_image --> The foreground image which is to be shadowed
	background_image --> Background image 
	image_name --> The name and format with which drop shadowed image is to be saved
	path --> The path at which image is to be stored. By default the image will be stored in current directory
	spread --> Spread for the shadow. By default the value is 1. The value can be varied between 0-1. As the value decreases, the spread of shadow increases


Output: It returns the path at which the image gets stored



'''


class DropShadow(object):
	
	def __init__(self,foreground_image,background_image,image_name,path = None,spread = 1):
		self.foreground_image = foreground_image
		self.background_image = background_image
		self.image_name = image_name
		self.path = path
		self.spread = spread


	def dropshadow(self):
		foreground_image = self.foreground_image
		background_image = self.background_image
		image_name = self.image_name
		path = self.path
		spread = self.spread


		image = Image.open(foreground_image)
		shadow=0x444444
		iterations = 3
		back = Image.open(background_image)
		new_width = image.size[0] + int(round(0.4 * image.size[0]))
		new_height = image.size[1] + int(round(0.4 * image.size[1]))
		back = back.resize((new_width,new_height), Image.ANTIALIAS)

		shadowLeft = int(round(spread * 0.2 * image.size[0]))
		shadowTop = int(round(spread * 0.2 * image.size[1]))

		back.paste(shadow, [shadowLeft, shadowTop, back.size[0] - shadowLeft, back.size[1] - shadowTop])

		n = 0
		while n < iterations:
    			back = back.filter(ImageFilter.BLUR)
    			n += 1

    		imageLeft = int(round(0.2 * image.size[0]))
		imageTop = int(round(0.2 * image.size[1]))
		back.paste(image, (imageLeft, imageTop))

		if path is not None:
			save_path = os.path.join(path,image_name)
			back.save(save_path)
			return path

		else:
			back.save(image_name)
			return os.getcwd()





